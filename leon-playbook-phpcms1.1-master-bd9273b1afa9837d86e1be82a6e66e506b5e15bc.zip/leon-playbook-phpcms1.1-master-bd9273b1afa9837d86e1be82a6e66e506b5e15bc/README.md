### Usage

```  shell
ansible-playbook -i inventory/[qa/prod] ./deploy.yml -e tag=$ver -e env=[qa/pro]
```
